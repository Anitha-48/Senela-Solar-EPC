// Central company information — replace placeholder values with real company data.
export const siteConfig = { 
  companyName: "Senela International Solar EPC",
  companyShortName: "Solar Epc and System",
  tagline: "",
  phone: "9585901999",
  email: "info@senelainternational.com",
  address: {
    line1: "K&T Business Tower, No.3, 3A, 3rd Floor, Gowriammal First Street, Rajagopal Nagar, Porur, Chennai - 600116, Tamil Nadu, India",
    line2: " Chennai, Tamil Nadu 600032",
    country: "India",
  },
   social: {
    linkedin: "https://www.linkedin.com/in/senela-international-901730315/",
    facebook: "https://www.facebook.com/senelasolar/",
    instagram: "https://www.instagram.com/senela_solar/",
    youtube: "https://www.youtube.com/@Senela_Solar_Solutions",
  },
}
